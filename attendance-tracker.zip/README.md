# Smart Attendance System

This is a sample folder structure for the Softsinc Internship Week 5 Team Project.

## Project Goal
A Face/QR-based attendance tracker.

## Team Roles
- Python Developer
- Data Scientist
- ML Engineer
- Team Lead
